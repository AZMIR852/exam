<?php
session_start();
require_once './config/database.php';
require_once './functions.php';

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Сервис заявок на ремонт</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h2>Добро пожаловать в сервис заявок на ремонт!</h2>
    <a href="login.php">Войти</a>
</body>
</html>
