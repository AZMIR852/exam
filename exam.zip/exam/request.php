<?php
session_start();
require_once './config/database.php';
require_once './functions.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if($_SESSION['role'] === 'admin') {
    $isAdmin = true;
}

if (isset($_GET['id'])) {
    $request_id = $_GET['id'];

    $stmt = $db->prepare("SELECT * FROM requests WHERE id = :id");
    $stmt->execute(['id' => $request_id]);
    $request = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$request) {
        die("Заявка не найдена!"); 
    }
} else {
    die("Неверный ID заявки.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Заявка #<?php echo $request['request_number']; ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h2>Заявка #<?php echo $request['id']; ?></h2>
    <p><strong>Оборудование:</strong> <?php echo $request['equipment']; ?></p>
    <p><strong>Тип неисправности:</strong> <?php echo $request['fault_type']; ?></p>
    <p><strong>Описание проблемы:</strong> <?php echo $request['problem_description']; ?></p>
    <p><strong>Клиент:</strong> <?php echo $request['client']; ?></p>
    <p><strong>Статус:</strong> <?php echo $request['status']; ?></p>
    <!-- if isAdmin -->
    <a href="delete_request.php?id=<?php echo $request['id']; ?>">Удалить</a>
    <a href="edit_request.php?id=<?php echo $request['id']; ?>"> Редактировать</a>
    <a href="dashboard.php">Вернуться к списку заявок</a>
</body>
</html>
