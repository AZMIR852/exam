<?php
session_start();
require_once './config/database.php';
require_once './functions.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

//? убрать
if($_SESSION['role'] !== 'admin') {
    echo "Недостаточно прав для удаления заявки.";
    //TODO кнопка вернуться
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $equipment = $_POST['equipment'];
    $fault_type = $_POST['fault_type'];
    $description = $_POST['description'];
    $client = $_POST['client']; 

    try {
        $stmt = $db->prepare("INSERT INTO requests (equipment, fault_type, problem_description, client, status, user_id) 
                               VALUES (:equipment, :fault_type, :description, :client, 'В ожидании', :user_id)");
        $stmt->execute([
            'equipment' => $equipment,
            'fault_type' => $fault_type,
            'description' => $description,
            'client' => $client,
            'user_id' => $_SESSION['user_id']
        ]);

        header('Location: dashboard.php'); 
        exit;
    } catch (PDOException $e) {
        echo "Ошибка при добавлении заявки: " . $e->getMessage();
    }
} 
?>

<!DOCTYPE html>
<html>
<head>
    <title>Новая заявка</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h2>Создать заявку</h2>
    <form method="post">
        <label for="equipment">Оборудование:</label>
        <input type="text" name="equipment" id="equipment" required><br>

        <label for="fault_type">Тип неисправности:</label>
        <input type="text" name="fault_type" id="fault_type" required><br>

        <label for="description">Описание проблемы:</label><br>
        <textarea name="description" id="description" rows="5" cols="40"></textarea><br>

        <label for="client">Клиент:</label>
        <input type="text" name="client" id="client" required><br>

        <button type="submit">Создать заявку</button>
    </form>
    <a href="dashboard.php">Вернуться к списку заявок</a> 
</body>
</html>
