<?php
session_start();
require_once './config/database.php';
require_once './functions.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Получение заявок из базы данных, сгруппированных по статусу
$stmt = $db->query("SELECT r.id, r.date_added, r.equipment, r.status, u.username AS creator 
                   FROM requests r
                   JOIN users u ON r.user_id = u.id
                   ORDER BY r.status, r.date_added DESC");
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Разделение заявок на категории по статусу
$requestsByStatus = [];
foreach ($requests as $request) {
    $requestsByStatus[$request['status']][] = $request;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Панель управления</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h2>Панель управления</h2>
    <p>Добро пожаловать, <?php echo $_SESSION['username']; ?>! <a href="logout.php">Выйти</a></p>

    <h3>Заявки на ремонт</h3>

    <?php foreach ($requestsByStatus as $status => $statusRequests): ?>
        <h4><?php echo $status; ?></h4> 
        <table>
            <thead>
                <tr>
                    <th>Номер</th>
                    <th>Дата добавления</th>
                    <th>Оборудование</th>
                    <th>Создатель</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($statusRequests as $request): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($request['id']); ?></td>
                        <td><?php echo htmlspecialchars($request['date_added']); ?></td>
                        <td><?php echo htmlspecialchars($request['equipment']); ?></td>
                        <td><?php echo htmlspecialchars($request['creator']); ?></td>
                        <td>
                            <a href="request.php?id=<?php echo $request['id']; ?>">Посмотреть</a>
                            <?php if ($_SESSION['user_id'] == $request['creator']): ?>
                                <a href="edit_request.php?id=<?php echo $request['id']; ?>">Редактировать</a>
                                <a href="delete_request.php?id=<?php echo $request['id']; ?>" onclick="return confirm('Вы уверены, что хотите удалить заявку?')">Удалить</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endforeach; ?>

    <a href="new_request.php">Создать заявку</a>
</body>
</html>