<?php

function connectDB() {
    $db_host = 'localhost'; 
    $db_name = 'test'; 
    $db_user = 'postgres'; 
    $db_pass = 'root'; 

    try {
        $db = new PDO("pgsql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $db;
    } catch(PDOException $e) {
        echo "Ошибка подключения к базе данных: " . $e->getMessage();
        die();
    }
}
function login($db, $username, $password) {
    // Подготовленный запрос для предотвращения SQL-инъекций
    $stmt = $db->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->execute(['username' => $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Проверка существования пользователя и хэша пароля
    if ($user && $password === $user['password']) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        return true;
    } 

    return false;
}

/*
-- Таблица пользователей
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(255) UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role VARCHAR(50) DEFAULT 'user' 
);

INSERT INTO users (username, password, role) VALUES ('admin', 'test', 'admin'); 
INSERT INTO users (username, password) VALUES ('user', 'test'); 

-- Таблица заявок
CREATE TABLE requests (
    id SERIAL PRIMARY KEY,
    date_added TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    equipment VARCHAR(255) NOT NULL,
    fault_type VARCHAR(255) NOT NULL,
    problem_description TEXT,
    client VARCHAR(255) NOT NULL,
    status VARCHAR(50) DEFAULT 'В ожидании',
    user_id INT REFERENCES users(id)
); 
*/