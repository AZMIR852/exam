<?php
session_start();
require_once './config/database.php';
require_once './functions.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if($_SESSION['role'] !== 'admin') {
    echo "Недостаточно прав для удаления заявки.";
    //TODO кнопка вернуться
    exit;
}

if (isset($_GET['id'])) {
    $request_id = $_GET['id'];

    // Получение заявки из базы данных
    $stmt = $db->prepare("SELECT * FROM requests WHERE id = :id");
    $stmt->execute(['id' => $request_id]);
    $request = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$request) {
        die("Заявка не найдена!");
    }

    // Обработка отправки формы
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $equipment = $_POST['equipment'];
        $fault_type = $_POST['fault_type'];
        $description = $_POST['description'];
        $client = $_POST['client'];

        try {
            $stmt = $db->prepare("UPDATE requests SET equipment = :equipment, fault_type = :fault_type, 
                                       problem_description = :description, client = :client 
                                       WHERE id = :id");
            $stmt->execute([
                'equipment' => $equipment,
                'fault_type' => $fault_type,
                'description' => $description,
                'client' => $client,
                'id' => $request_id
            ]);

            header('Location: dashboard.php');
            exit;
        } catch (PDOException $e) {
            echo "Ошибка при обновлении заявки: " . $e->getMessage();
        }
    }
} else {
    die("Неверный ID заявки.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Редактировать заявку #<?php echo $request['request_number']; ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h2>Редактировать заявку #<?php echo $request['id']; ?></h2>
    <form method="post">
        <label for="equipment">Оборудование:</label>
        <input type="text" name="equipment" id="equipment" value="<?php echo htmlspecialchars($request['equipment']); ?>" required><br>

        <label for="fault_type">Тип неисправности:</label>
        <input type="text" name="fault_type" id="fault_type" value="<?php echo htmlspecialchars($request['fault_type']); ?>" required><br>

        <label for="description">Описание проблемы:</label><br>
        <textarea name="description" id="description" rows="5" cols="40"><?php echo htmlspecialchars($request['problem_description']); ?></textarea><br>

        <label for="client">Клиент:</label>
        <input type="text" name="client" id="client" value="<?php echo htmlspecialchars($request['client']); ?>" required><br>

        <button type="submit">Сохранить изменения</button>
    </form>
    <a href="dashboard.php">Вернуться к списку заявок</a>
</body>
</html>
