<?php
require_once './functions.php';

$db = connectDB();