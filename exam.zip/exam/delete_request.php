<?php
session_start();
require_once './config/database.php';
require_once './functions.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if($_SESSION['role'] !== 'admin') {
    echo "Недостаточно прав для удаления заявки.";
    //TODO кнопка вернуться
    exit;
}

if (isset($_GET['id'])) {
    $request_id = $_GET['id'];

    try {
        $stmt = $db->prepare("DELETE FROM requests WHERE id = :id");
        $stmt->execute(['id' => $request_id]);

        header('Location: dashboard.php');
        exit;
    } catch (PDOException $e) {
        echo "Ошибка при удалении заявки: " . $e->getMessage();
    }
} else {
    die("Неверный ID заявки.");
}
